const images = document.querySelectorAll(".gallery-img");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");

const nextBtn = document.querySelector(".next");
const prevBtn = document.querySelector(".prev");
const closeBtn = document.querySelector(".close");

let currentIndex = 0;

images.forEach((img,index)=>{
img.addEventListener("click",()=>{
lightbox.style.display="flex";
lightboxImg.src = img.src;
currentIndex=index;
});
});

nextBtn.onclick=()=>{
currentIndex++;
if(currentIndex>=images.length){
currentIndex=0;
}
lightboxImg.src = images[currentIndex].src;
};

prevBtn.onclick=()=>{
currentIndex--;
if(currentIndex<0){
currentIndex=images.length-1;
}
lightboxImg.src = images[currentIndex].src;
};

closeBtn.onclick=()=>{
lightbox.style.display="none";
};